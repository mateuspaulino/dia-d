//
//  SelectContactViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 14/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class SelectContactViewController: UIViewController {

    @IBOutlet var imgContactType: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        imgContactType.userInteractionEnabled = true
        var gesture = UITapGestureRecognizer(target: self, action: "next:")
        //imgContactType.addGestureRecognizer(<#gestureRecognizer: UIGestureRecognizer#>)
        imgContactType.addGestureRecognizer(gesture)


        
        
        // Do any additional setup after loading the view.
    }
    
    func next(sender: AnyObject) {
        println("a")
        self.performSegueWithIdentifier("sgOk", sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
