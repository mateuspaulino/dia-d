//
//  TblCell.swift
//  CustomTableCell
//
//  Created by Andrew Seeley on 6/10/2014.
//  Copyright (c) 2014 Seemu. All rights reserved.
//

import UIKit

class TblCell: UITableViewCell {

    

    @IBOutlet var imgContact: UIImageView!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblPhone: UILabel!
    @IBOutlet var lblEmail: UILabel!
    @IBOutlet var imgTick: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
