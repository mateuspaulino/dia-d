//
//  InviteViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 13/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit
import AddressBook
import AddressBookUI

class InviteViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {

    
    var tableData: [String] = ["Hello", "My", "Table"]
    var tableImages: [String] = ["stick", "marker", "profile_default"]
    
    var contactNames: [String] = []
    var contactNos: [String] = []
    var contactEmails: [String] = []
    var contactImgs: [UIImage] = []
    var contactSelected: [Bool] = []
    
    @IBOutlet var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Get contact info from address book
        getAB()
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        
        
        // Register custom cell
        var nib = UINib(nibName: "vwTblCell", bundle: nil)
        tableView.registerNib(nib, forCellReuseIdentifier: "cell")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.contactNames.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell 	{
        var cell:TblCell = self.tableView.dequeueReusableCellWithIdentifier("cell") as! TblCell
        cell.imageView?.backgroundColor = UIColor.redColor()
    
        cell.imgContact.image = contactImgs[indexPath.row]
        cell.lblName.text = contactNames[indexPath.row]
        cell.lblPhone.text = contactNos[indexPath.row]
        cell.lblEmail.text = contactEmails[indexPath.row]
        cell.imgTick.hidden = !contactSelected[indexPath.row]
        
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //println("Row \(indexPath.row) selected")
        self.performSegueWithIdentifier("sgContact", sender: self)
        let cell = self.tableView.cellForRowAtIndexPath(indexPath) as! TblCell
        checkCell(cell)
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        let cell = self.tableView.cellForRowAtIndexPath(indexPath) as! TblCell
        checkCell(cell)
    }
    
    func checkCell(cell: TblCell) {
        if(cell.accessoryType == .None) {
            cell.accessoryType = .Checkmark
        } else {
            cell.accessoryType = .None
        }
        
        //cell.imgTick.hidden = !cell.imgTick.hidden
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 77
    }
    
    /*********** Address Book Info ***********/
    
    func extractABAddressBookRef(abRef: Unmanaged<ABAddressBookRef>!) -> ABAddressBookRef? {
        if let ab = abRef {
            return Unmanaged<NSObject>.fromOpaque(ab.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    func getAB() {
        if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.NotDetermined) {
            println("requesting access...")
            var errorRef: Unmanaged<CFError>? = nil
            addressBook = extractABAddressBookRef(ABAddressBookCreateWithOptions(nil, &errorRef))
            ABAddressBookRequestAccessWithCompletion(addressBook, { success, error in
                if success {
                    self.getContactNames()
                }
                else {
                    println("error")
                }
            })
        }
        else if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Denied || ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Restricted) {
            println("access denied")
        }
        else if (ABAddressBookGetAuthorizationStatus() == ABAuthorizationStatus.Authorized) {
            println("access granted")
            self.getContactNames()
        }
    }
    
    func getContactNames() {
        var errorRef: Unmanaged<CFError>?
        addressBook = extractABAddressBookRef(ABAddressBookCreateWithOptions(nil, &errorRef))
        var contactList: NSArray = ABAddressBookCopyArrayOfAllPeople(addressBook).takeRetainedValue()
        println("records in the array \(contactList.count)")
        
        for record:ABRecordRef in contactList {
            var contactPerson: ABRecordRef = record
            var contactName: String = ABRecordCopyCompositeName(contactPerson).takeRetainedValue() as NSString as String
            contactNames.append(contactName)
            println(contactName)
            
            // Phones
            let unmanagedPhones = ABRecordCopyValue(record, kABPersonPhoneProperty)
            let phones: ABMultiValueRef =
            Unmanaged.fromOpaque(unmanagedPhones.toOpaque()).takeUnretainedValue()
                as NSObject as ABMultiValueRef
            
            let countOfPhones = ABMultiValueGetCount(phones)
            
            var phoneNo = ""
            for index in 0..<countOfPhones{
                let unmanagedPhone = ABMultiValueCopyValueAtIndex(phones, index)
                let phone: String = Unmanaged.fromOpaque(
                    unmanagedPhone.toOpaque()).takeUnretainedValue() as NSObject as! String
                phoneNo = phone
                println(phone)
            }
            contactNos.append(phoneNo)
            
            // Emails
            var email = ""
            let emailArray:ABMultiValueRef = extractABEmailRef(ABRecordCopyValue(record, kABPersonEmailProperty))!
            for (var j = 0; j < ABMultiValueGetCount(emailArray); ++j) {
                var emailAdd = ABMultiValueCopyValueAtIndex(emailArray, j)
                var myString = extractABEmailAddress(emailAdd)
                email = myString!
                println(myString)
            }
            contactEmails.append(email)
            
            // Image
            var pic = UIImage(named: "profile_default")
            var image =  ABPersonCopyImageDataWithFormat(contactPerson, kABPersonImageFormatThumbnail)?.takeRetainedValue()
            if image != nil {
                pic = UIImage(data: image!)
            }
            contactImgs.append(pic!)
            contactSelected.append(false)
            
        }
    }
    
    func extractABEmailRef (abEmailRef: Unmanaged<ABMultiValueRef>!) -> ABMultiValueRef? {
        if let ab = abEmailRef {
            return Unmanaged<NSObject>.fromOpaque(ab.toOpaque()).takeUnretainedValue()
        }
        return nil
    }
    
    func extractABEmailAddress (abEmailAddress: Unmanaged<AnyObject>!) -> String? {
        if let ab = abEmailAddress {
            return Unmanaged.fromOpaque(abEmailAddress.toOpaque()).takeUnretainedValue() as CFStringRef as String
        }
        return nil
    }

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
