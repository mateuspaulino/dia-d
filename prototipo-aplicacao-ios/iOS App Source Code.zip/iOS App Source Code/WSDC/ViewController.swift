//
//  ViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 12/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblNetworkCount: UILabel!
    
    @IBOutlet var profilePic: UIImageView!
    @IBOutlet var donorPic: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

