//
//  ProfileViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 14/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet var txtDate: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.parentViewController?.navigationItem.titleView = UIImageView(image: image)
        
        self.tabBarController?.tabBar.tintColor = cOrange
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func dateFieldEditing(sender: UITextField) {
        var datePickerView:UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePickerMode.Date
        sender.inputView = datePickerView
        datePickerView.addTarget(self, action: Selector("datePickerValueChanged:"), forControlEvents: UIControlEvents.ValueChanged)
    }
    
    func datePickerValueChanged(sender:UIDatePicker) {
        
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.MediumStyle
        dateFormatter.timeStyle = NSDateFormatterStyle.NoStyle
        txtDate.text = dateFormatter.stringFromDate(sender.date)
        
        txtDate.resignFirstResponder()
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
