//
//  LoginViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 14/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet var btnLogin: UIButton!
    @IBOutlet var btnCreateAccount: UIButton!
    
    @IBOutlet var txtEmai: UITextField!
    @IBOutlet var txtPass: UITextField!
    
    var phColor = UIColor(red: 255, green: 255, blue: 255, alpha: 0.5)
  
    override func viewDidLoad() {
        super.viewDidLoad()

        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        //btnLogin.layer.cornerRadius = 10
        //btnCreateAccount.layer.cornerRadius = 10
        
        txtEmai.addTarget(self, action: "txtEmaiDidChange:", forControlEvents: UIControlEvents.EditingChanged)
        txtPass.addTarget(self, action: "txtPassDidChange:", forControlEvents: UIControlEvents.EditingChanged)
        

        
        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        txtEmai.resignFirstResponder()
        txtPass.resignFirstResponder()
    }
    
    func txtEmaiDidChange(textField: UITextField) {
        
        println(isValidEmail(txtEmai.text))
        
        if(count(txtEmai.text) == 0) {
            txtEmai.rightViewMode = UITextFieldViewMode.Never
        } else {
            if(isValidEmail(txtEmai.text) == true) {
                txtEmai.rightViewMode = UITextFieldViewMode.Always
                txtEmai.rightView = UIImageView(image: UIImage(named: "tickorange"))
            } else {
                txtEmai.rightViewMode = UITextFieldViewMode.Never
            }
        }
    }
    
    func txtPassDidChange(textField: UITextField) {
        if(count(txtPass.text) == 0) {
            txtPass.rightViewMode = UITextFieldViewMode.Never
        } else {
            txtPass.rightViewMode = UITextFieldViewMode.Always
            txtPass.rightView = UIImageView(image: UIImage(named: "tickorange"))
        }
    }
    
    func isValidEmail(testStr:String) -> Bool {
        let regex = NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .CaseInsensitive, error: nil)
        return regex?.firstMatchInString(testStr, options: nil, range: NSMakeRange(0, count(testStr))) != nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
