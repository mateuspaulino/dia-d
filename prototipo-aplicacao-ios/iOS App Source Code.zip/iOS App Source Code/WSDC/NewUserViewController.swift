//
//  NewUserViewController.swift
//  
//
//  Created by Andrew Seeley on 13/08/2015.
//
//

import UIKit

class NewUserViewController: UIViewController {

    @IBOutlet var swDonor: UISwitch!
    
    @IBOutlet var txtEmai: UITextField!
    @IBOutlet var txtPass: UITextField!
    
    @IBOutlet var txtBirthDate: UITextField!
    
    @IBOutlet var btnYes: UIButton!
    @IBOutlet var btnNo: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        
        txtEmai.addTarget(self, action: "txtEmaiDidChange:", forControlEvents: UIControlEvents.EditingChanged)
        txtPass.addTarget(self, action: "txtPassDidChange:", forControlEvents: UIControlEvents.EditingChanged)
        
    }
    
    override func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
        txtEmai.resignFirstResponder()
        txtPass.resignFirstResponder()
    }
    
    
    func txtEmaiDidChange(textField: UITextField) {
        
        println(isValidEmail(txtEmai.text))
        
        if(count(txtEmai.text) == 0) {
            txtEmai.rightViewMode = UITextFieldViewMode.Never
        } else {
            if(isValidEmail(txtEmai.text) == true) {
                txtEmai.rightViewMode = UITextFieldViewMode.Always
                txtEmai.rightView = UIImageView(image: UIImage(named: "tickorange"))
            } else {
                txtEmai.rightViewMode = UITextFieldViewMode.Never
            }
        }
    }
    
    func txtPassDidChange(textField: UITextField) {
        if(count(txtPass.text) == 0) {
            txtPass.rightViewMode = UITextFieldViewMode.Never
        } else {
            txtPass.rightViewMode = UITextFieldViewMode.Always
            txtPass.rightView = UIImageView(image: UIImage(named: "tickorange"))
        }
    }
    
    func isValidEmail(testStr:String) -> Bool {
        let regex = NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .CaseInsensitive, error: nil)
        return regex?.firstMatchInString(testStr, options: nil, range: NSMakeRange(0, count(testStr))) != nil
    }


    @IBAction func textFieldEditing(sender: UITextField) {
        var datePickerView:UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePickerMode.Date
        sender.inputView = datePickerView
        datePickerView.addTarget(self, action: Selector("datePickerValueChanged:"), forControlEvents: UIControlEvents.ValueChanged)
    
    }
    
    func datePickerValueChanged(sender:UIDatePicker) {
        
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.MediumStyle
        dateFormatter.timeStyle = NSDateFormatterStyle.NoStyle
        txtBirthDate.text = dateFormatter.stringFromDate(sender.date)
        
        //txtBirthDate.resignFirstResponder()
        
    }

    @IBAction func dYes(sender: UIButton) {
        btnNo.backgroundColor = UIColor(red: 151/255, green: 153/255, blue: 139/255, alpha: 1)
        sender.backgroundColor = UIColor(red: 255/255, green: 0/255, blue: 42/255, alpha: 1)
    }
    
    @IBAction func dNo(sender: UIButton) {
        btnYes.backgroundColor = UIColor(red: 151/255, green: 153/255, blue: 139/255, alpha: 1)
        sender.backgroundColor = UIColor(red: 255/255, green: 0/255, blue: 42/255, alpha: 1)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
