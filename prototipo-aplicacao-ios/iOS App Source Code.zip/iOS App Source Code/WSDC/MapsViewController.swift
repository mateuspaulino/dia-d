//
//  MapsViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 12/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit
import GoogleMaps

class MapsViewController: UIViewController {

  
    @IBOutlet var vwMap: GMSMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        
        vwMap.myLocationEnabled = true
        vwMap.camera = GMSCameraPosition.cameraWithLatitude(-23.543027,
            longitude: -46.650857, zoom: 11)
        
        var marker = GMSMarker()
        marker.position = CLLocationCoordinate2DMake(-23.543027, -46.650857)
        marker.title = "Hemocentro da Santa Casa de São Paulo"
        marker.snippet = "R. Marquês de Itu, 579 - Vila Buarque, São Paulo"
        marker.icon = UIImage(named: "marker")
        marker.map = vwMap
        
        var marker2 = GMSMarker()
        marker2.position = CLLocationCoordinate2DMake(-23.483570, -46.631607)
        marker2.title = "DFundação Prosangue Hemocentro São Paulo"
        marker2.snippet = "R. Voluntários da Pátria, 4301, São Paulo"
        marker2.icon = UIImage(named: "marker")
        marker2.map = vwMap
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
