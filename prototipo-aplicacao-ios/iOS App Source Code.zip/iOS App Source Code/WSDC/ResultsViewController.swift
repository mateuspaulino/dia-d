//
//  ResultsViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 14/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {

    var passed = Bool()
    var test = 1
    
    @IBOutlet var lblResult: UILabel!
    @IBOutlet var btnResultAction: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        println(passed)
        if(passed == true) {
            lblResult.text = "Parabéns você pode doar sangue"
            btnResultAction.setTitle("Marcar Doação", forState: .Normal)
        } else {
            lblResult.text = "Você não pode doar sangue, mas você pode convidar amigos para experimentar o questionário"
            btnResultAction.setTitle("Convidar amigos", forState: .Normal)
        }
        
        // Get passes message
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
