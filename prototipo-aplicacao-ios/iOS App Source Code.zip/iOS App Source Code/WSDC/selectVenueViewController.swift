//
//  selectVenueViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 14/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class selectVenueViewController: UIViewController, UIScrollViewDelegate {

    var scroll = UIScrollView()
    var imgVenue = ["chall_sel", "chall_sel", "chall_sel", "chall_sel"]
    

    @IBOutlet var imgFriends: UIImageView!
    @IBOutlet var imgChallenge: UIImageView!
    @IBOutlet var imgDate: UIImageView!
    @IBOutlet var imgCafe: UIImageView!
    
    @IBOutlet var descriptionLabel: UILabel!
    
    var scrollHeight = CGFloat()
    var scrollWidth = CGFloat()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        var sw = UIScreen.mainScreen().bounds.width
        var shc = sw / 2 // Screen horizon middle
        scrollWidth = UIScreen.mainScreen().bounds.width
        
        scrollHeight = 300
        scrollWidth = 300

        // Add scroll at the bottom to show keyboard image example and unlock button
        scroll = UIScrollView(frame: CGRectMake(shc - scrollWidth / 2, descriptionLabel.bounds.origin.y + 150, scrollWidth, 300));
        scroll.pagingEnabled = true
        //scroll.backgroundColor = UIColor.blackColor()
        var imgCount = CGFloat(imgVenue.count)
        scroll.contentSize = CGSizeMake(imgCount * scrollWidth, scrollHeight)
        scroll.delegate = self
        self.view.addSubview(scroll)
        
        setScrollImages()

        // Do any additional setup after loading the view.
    }
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
        var pg = getScrollPage()
        deselectAll()
        
        
        switch(pg) {
        case 0:
            //println("0")
            imgCafe.image = UIImage(named: "cafe")
        case 1:
            //println("1")
            imgFriends.image = UIImage(named: "friend")
        case 2:
            //println("2")
            imgChallenge.image = UIImage(named: "chall")
        case 3:
            //println("3")
            imgDate.image = UIImage(named: "date")
        default:
            println("no")
        }
        
        //println(getScrollPage())
    }
    
    func deselectAll() {
        imgCafe.image = UIImage(named: "cafe_d")
        imgChallenge.image = UIImage(named: "chall_d")
        imgDate.image = UIImage(named: "date_d")
        imgFriends.image = UIImage(named: "friend_d")
    }

    func setScrollImages() {
        
        var xPos: CGFloat = 0.0
        var i: Int = 0
        for image in imgVenue {
            
            var imageView = UIImageView(frame: CGRectMake(xPos, 0, scrollWidth, scrollHeight));
            var currimage = UIImage(named: image);
            imageView.image = currimage
            imageView.tag = 1
            scroll.addSubview(imageView)
            
            
            xPos = xPos + scrollWidth
            i++
        }
    }
    
    // Return the current selected page(Index) on the scroll view
    func getScrollPage() -> NSInteger {
        var width: CGFloat = scroll.frame.size.width
        var page: NSInteger = Int((scroll.contentOffset.x + (0.5 * width) / width) / width)
        return page
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
