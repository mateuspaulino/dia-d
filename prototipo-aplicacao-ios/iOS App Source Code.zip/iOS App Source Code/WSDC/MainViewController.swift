//
//  MainViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 13/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit

class MainViewController: UIViewController, UIPageViewControllerDataSource {

    
    // MARK: - Variables
    private var pageViewController: UIPageViewController?
    
    private let contentText =
    ["Agende sua próxima doação de sangue e vá com seus amigos. ",
        "Descubra se você atende os requisitos para doação com nosso quiz interativo!",
        ""
    ];
    
    private let contentImg = ["tut1", "tut2", "tut3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createPageViewController()
        setupPageControl()

        UIPageControl.appearance().pageIndicatorTintColor = UIColor.grayColor()
        UIPageControl.appearance().currentPageIndicatorTintColor = cOrange
        UIPageControl.appearance().backgroundColor = self.view.backgroundColor
        //UIPageControl.appearance().backgroundColor = UIColor.redColor()
        
        //UIPageControl.appearance().layer.borderColor = UIColor.redColor().CGColor
        //UIPageControl.appearance().layer.borderWidth = 10
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    private func createPageViewController() {
        
        let pageController = self.storyboard!.instantiateViewControllerWithIdentifier("PageController") as! UIPageViewController
        pageController.dataSource = self
        
        if contentText.count > 0 {
            let firstController = getItemController(0)!
            let startingViewControllers: NSArray = [firstController]
            pageController.setViewControllers(startingViewControllers as [AnyObject], direction: UIPageViewControllerNavigationDirection.Forward, animated: false, completion: nil)
        }
        
        pageViewController = pageController
        addChildViewController(pageViewController!)
        self.view.addSubview(pageViewController!.view)
        pageViewController!.didMoveToParentViewController(self)
    }
    
    private func setupPageControl() {
        let appearance = UIPageControl.appearance()
        appearance.pageIndicatorTintColor = UIColor.grayColor()
        appearance.currentPageIndicatorTintColor = UIColor.whiteColor()
        appearance.backgroundColor = UIColor.darkGrayColor()
    }
    
    // MARK: - UIPageViewControllerDataSource
    
    func pageViewController(pageViewController: UIPageViewController, viewControllerBeforeViewController viewController: UIViewController) -> UIViewController? {
        
        let itemController = viewController as! PageItemController
        
        showLogin(itemController.itemIndex)
        
        if itemController.itemIndex > 0 {
            return getItemController(itemController.itemIndex-1)
        }
        
        return nil
    }
    
    func pageViewController(pageViewController: UIPageViewController, viewControllerAfterViewController viewController: UIViewController) -> UIViewController? {
        
        let itemController = viewController as! PageItemController
        
        showLogin(itemController.itemIndex)
        
        if itemController.itemIndex+1 < contentText.count {
            return getItemController(itemController.itemIndex+1)
        }
        
        return nil
    }
    
    func showLogin(itemIndex: Int) {
        println(itemIndex)
        if(itemIndex == 2) {
            self.performSegueWithIdentifier("sgLogin", sender: self)
        }
    }
    
    private func getItemController(itemIndex: Int) -> PageItemController? {
 
        
        if itemIndex < contentText.count {
            let pageItemController = self.storyboard!.instantiateViewControllerWithIdentifier("ItemController") as! PageItemController
            pageItemController.itemIndex = itemIndex
            pageItemController.contentText = contentText[itemIndex]
            pageItemController.contentImg = contentImg[itemIndex]
            return pageItemController
        }
        
        return nil
    }
    
    // MARK: - Page Indicator
    
    func presentationCountForPageViewController(pageViewController: UIPageViewController) -> Int {
        return contentText.count
    }
    
    func presentationIndexForPageViewController(pageViewController: UIPageViewController) -> Int {
        return 0
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
