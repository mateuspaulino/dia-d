//
//  QuizViewController.swift
//  WSDC
//
//  Created by Andrew Seeley on 13/08/2015.
//  Copyright (c) 2015 Seemu. All rights reserved.
//

import UIKit
import Koloda
import pop

private var numberOfCards: UInt = 11

class QuizViewController: UIViewController, KolodaViewDataSource, KolodaViewDelegate {


    @IBOutlet weak var kolodaView: KolodaView!

    // The correct answers, 0 = left, 1 = right
    var answerKey = [1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0]
    var passed = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        kolodaView.dataSource = self
        kolodaView.delegate = self
        
        self.modalTransitionStyle = UIModalTransitionStyle.FlipHorizontal
        
        // Navbar Stuff
        self.navigationController?.navigationBar.barTintColor = cOrange
        var image = UIImage(named: "logowhite")
        self.navigationItem.titleView = UIImageView(image: image)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: IBActions
    @IBAction func leftButtonTapped() {
        kolodaView?.swipe(SwipeResultDirection.Left)
    }
    
    @IBAction func rightButtonTapped() {
        kolodaView?.swipe(SwipeResultDirection.Right)
    }
    
    @IBAction func undoButtonTapped() {
        kolodaView?.revertAction()
    }
    
    //MARK: KolodaViewDataSource
    func kolodaNumberOfCards(koloda: KolodaView) -> UInt {
        return numberOfCards
    }
    
    func kolodaViewForCardAtIndex(koloda: KolodaView, index: UInt) -> UIView {
        return UIImageView(image: UIImage(named: "Quiz_\(index + 1)"))
    }
    func kolodaViewForCardOverlayAtIndex(koloda: KolodaView, index: UInt) -> OverlayView? {
        return NSBundle.mainBundle().loadNibNamed("OverlayView",
            owner: self, options: nil)[0] as? OverlayView
    }
    
    //MARK: KolodaViewDelegate
    
    func kolodaDidSwipedCardAtIndex(koloda: KolodaView, index: UInt, direction: SwipeResultDirection) {
        println(index)

        if(direction == SwipeResultDirection.Left) {
            if(answerKey[Int(index)] == 1) {
                passed = false
            }
        } else if (direction == SwipeResultDirection.Right) {
            if(answerKey[Int(index)] == 0) {
                passed = false
            }
        }
        
        // Last cared answered go to results
        if(Int(index) == Int(numberOfCards - 1)) {
            println("Results")
            println(passed)
            
            performSegueWithIdentifier("sgResult", sender: self)
            
        }
        
        
        //Example: loading more cards
        if index >= 3 {
            numberOfCards = 11
            kolodaView.reloadData()
        }
    }
    
    func kolodaDidRunOutOfCards(koloda: KolodaView) {
        //Example: reloading
        kolodaView.resetCurrentCardNumber()
    }
    
    func kolodaDidSelectCardAtIndex(koloda: KolodaView, index: UInt) {
        println(index)
        //UIApplication.sharedApplication().openURL(NSURL(string: "http://yalantis.com/")!)
    }
    
    func kolodaShouldApplyAppearAnimation(koloda: KolodaView) -> Bool {
        return true
    }
    
    func kolodaShouldMoveBackgroundCard(koloda: KolodaView) -> Bool {
        return true
    }
    
    func kolodaShouldTransparentizeNextCard(koloda: KolodaView) -> Bool {
        return true
    }
    
    func kolodaBackgroundCardAnimation(koloda: KolodaView) -> POPPropertyAnimation? {
        return nil
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
 
        var dVC = segue.destinationViewController as! ResultsViewController
        dVC.passed = passed
    }


}
