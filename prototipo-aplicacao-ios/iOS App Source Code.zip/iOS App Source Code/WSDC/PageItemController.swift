
import UIKit

class PageItemController: UIViewController {
    
    @IBOutlet var imgLogo: UIImageView!
    // MARK: - Variables
    var itemIndex: Int = 0
    var contentText: String = ""
    var contentImg: String = ""

    @IBOutlet var contentTextView: UILabel!
    @IBOutlet var contentImgVw: UIImageView!
    
    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        contentTextView.text = contentText
        contentImgVw.image = UIImage(named: contentImg)
        
        if(contentImg == "tut1" || contentImg == "tut2") {
            contentImgVw.hidden = false
            imgLogo.hidden = false
        } else {
            contentImgVw.hidden = true
            imgLogo.hidden = true
        }
        
    }
    
}
